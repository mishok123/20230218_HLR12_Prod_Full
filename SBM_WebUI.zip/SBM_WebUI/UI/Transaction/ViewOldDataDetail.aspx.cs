﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using SBM_BLC1.Common;
using SBM_BLC1.Entity.Common;
using SBM_BLC1.Configuration;
using SBM_BLC1.Entity.Transaction;
using SBM_BLC1.Transaction;
using SBM_BLC1.Entity.Configuration;
using System.Collections;
using SBM_BLC1.Common;
using SBM_BLC1.DAL.Common;
using System.Drawing;
using System.Text;
//using SBM_BLC1.DAL.Transaction;

namespace SBM_WebUI.mp
{
    public partial class ViewOldDataDetail : System.Web.UI.Page
    {
        #region Local Variable
        CryptographyManager oCrypManager = new CryptographyManager();
        public const string OBJ_REG_NO = "RegNo";
        public const string OBJ_PAGE_ID = "sPageID";
        #endregion Local Variable


        protected void Page_Load(object sender, EventArgs e)
        {            
            if (Session[Constants.SES_USER_CONFIG] != null)
            {
                if (!Page.IsPostBack)
                {
                    Util.InvalidateSession();
                    InitializeData();
                    //This is for Page Permission
                    CheckPermission chkPer = new CheckPermission();
                    Config oConfig = (Config)Session[Constants.SES_USER_CONFIG];
                    if (!chkPer.CheckPagePermission((Control)this.Page, oConfig, (int)Constants.PAGEINDEX_TRANS.SP_ISSUE_VIEW))
                    {
                        Response.Redirect(Constants.PAGE_ERROR, false);
                    }
                    //End Of Page Permission
                }
            }
            else
            {
                Response.Redirect(Constants.PAGE_LOGIN, false);
            }
        }


        #region InitializeData
        private void InitializeData()
        {
            hdRegNo.Value = ""; 
            // Dropdown load SPType
            DDListUtil.LoadDDLFromDB(ddlSpType, "SPTypeID", "TypeDesc", "SPMS_SPType", true);
            DDListUtil.LoadDDLFromDB(ddlBranch, "BranchID", "BranchName", "SPMS_Branch", true);
            DDListUtil.LoadDDLFromDB(ddlCollectionBranch, "BranchID", "BranchName", "SPMS_Branch", true);
            DDListUtil.LoadDDLFromDB(ddlPDCurrency, "CurrencyID", "CurrencyCode", "SPMS_Currency", true);
            // end of Intial Data

            // Issue Details
            txtIssueDate.Text = DateTime.Now.ToString(Constants.DATETIME_FORMAT);
            Util.ControlEnabled(ddlSpType, false);
            Util.ControlEnabled(ddlBranch, false);
            Util.ControlEnabled(ddlCollectionBranch, false);
            Util.ControlEnabled(txtIssueDate, false);
            
            Util.ControlEnabled(txtCustomerType, false);
            Util.ControlEnabled(txtAppliedAmount, false);

            // Bond Holder Details
            Util.ControlEnabled(txtBHDHolderName, false);
            Util.ControlEnabled(txtIssueName, false);
            Util.ControlEnabled(txtBHDAddress, false);
            Util.ControlEnabled(txtBHDRelation, false);
            Util.ControlEnabled(txtBHPassport, false);

            // payment mode
            Util.ControlEnabled(txtPaymentMode, false);
            Util.ControlEnabled(ddlPDCurrency, false);
            Util.ControlEnabled(txtPDAccDraftNo, false);
            Util.ControlEnabled(txtPDAccName, false);
            //Util.ControlEnabled(txtPDConvRate, false);
            Util.ControlEnabled(txtPDPaymentAmount, false);

            Util.ControlEnabled(txtOldRegNo, false);
            Util.ControlEnabled(txtCreateBy, false);
            Util.ControlEnabled(txtModifiedBy, false);
            Util.ControlEnabled(txtConfirmed, false);
            Util.ControlEnabled(txtCreateDate, false);
            Util.ControlEnabled(txtModifiedDate, false);


            gvCustomerDetail.DataSource = null;
            gvCustomerDetail.DataBind();

            gvNomDetail.DataSource = null;
            gvNomDetail.DataBind();

            gvInterest.DataSource = null;
            gvInterest.DataBind();

            gvEncashment.DataSource = null;
            gvEncashment.DataBind();
            //gvNomDemon.DataSource = null;
            //gvNomDemon.DataBind();

            gvDenomDetail.DataSource = null;
            gvDenomDetail.DataBind();

            //ddlTaxYear.SelectedValue = DateTime.Today.Year.ToString();

            string sRegNo = "";
            sRegNo=Request.QueryString["qRegNo"];
            if (!string.IsNullOrEmpty(sRegNo))
            {
                sRegNo = oCrypManager.GetDecryptedString(sRegNo, Constants.CRYPT_PASSWORD_STRING);
            }
            if (sRegNo == null)
            {
                sRegNo = "";
            }
            if (sRegNo.Trim() != "")
            {
                LoadDataByID(sRegNo);
            }
            
        }
        #endregion InitializeData


        protected void btnLoad_Click(object sender, EventArgs e)
        {
            if (txtRegistrationNo.Text.Length > 0)
            {
                LoadDataByID(txtRegistrationNo.Text);
            }
        }

        public void PopupIssueSearchLoadAction(string sRegNo,  string sTransNo, string sApprovalStaus)
        {
            if (!string.IsNullOrEmpty(sRegNo))
            {
                LoadDataByID(sRegNo);
            }
        }

        public void PopErrorMsgAction(string sType)
        {
            if (sType.Equals(Constants.BTN_APPROVE) || sType.Equals(Constants.BTN_REJECT))
            {
               // Response.Redirect(Constants.PAGE_PRIMARY_APPROVAL + "?pType=" + Convert.ToString((int)Constants.PAGEINDEX_CONFIG.SP_WISEA_CCOUNT).PadLeft(5, '0'), false);
            }
            else
            {
                // no action
            }
        }

        protected void btnRegSearch_Click(object sender, EventArgs e)
        {            
            if (!string.IsNullOrEmpty(txtRegistrationNo.Text))
            {
                LoadDataByID(txtRegistrationNo.Text);
            }
        }


        public void LoadDataByID(string sRegNo)
        {
            try
            {
            OldDataDAL oOldDataDAL = new OldDataDAL();
            Result oResult = new Result();
            Config oConfig = (Config)Session[Constants.SES_USER_CONFIG];

            oResult = oOldDataDAL.LoadIssueDetailsByRegNo(sRegNo);

            //Load Issue Details
            if (oResult.Status)
            {
                txtRegistrationNo.Text = sRegNo;
                hdRegNo.Value = sRegNo;

                DataTable dtISS = (DataTable)oResult.Return;
                DDListUtil.Assign(ddlSpType, DB.GetDBValue(dtISS.Rows[0]["BondSales_SPType"]));
                txtCustomerType.Text = DB.GetDBValue(dtISS.Rows[0]["BondSales_cType"]);
                DDListUtil.Assign(ddlBranch, DB.GetDBValue(dtISS.Rows[0]["BondSales_BranchID"]));
                DDListUtil.Assign(ddlCollectionBranch, DB.GetDBValue(dtISS.Rows[0]["BondSales_ColBranchID"]));
                txtIssueDate.Text = Date.GetDateTimeByString(dtISS.Rows[0]["BondSales_SalesDate"].ToString()).ToString(Constants.DATETIME_FORMAT);


                txtBHDHolderName.Text = DB.GetDBValue(dtISS.Rows[0]["BondHolder_Name"]);
                txtBHDRelation.Text = DB.GetDBValue(dtISS.Rows[0]["BondHolder_Realation"]);
                txtBHDAddress.Text = DB.GetDBValue(dtISS.Rows[0]["BondHolder_Address"]);
                txtBHPassport.Text = DB.GetDBValue(dtISS.Rows[0]["BondHolder_Passport"]);

                txtIssueName.Text = DB.GetDBValue(dtISS.Rows[0]["bfCustomerName"]);

                gvCustomerDetail.DataSource = dtISS;
                gvCustomerDetail.DataBind();

                txtAppliedAmount.Text = DB.GetDBIntValue(dtISS.Rows[0]["IssueAmount"]).ToString("0.00");


                DDListUtil.Assign(ddlPDCurrency, DB.GetDBValue(dtISS.Rows[0]["BondSales_SPCurrency"]));
                txtPaymentMode.Text = DB.GetDBValue(dtISS.Rows[0]["BondSales_PayMode"]);
                txtPDAccDraftNo.Text = DB.GetDBValue(dtISS.Rows[0]["BondSales_AccNo"]) + ' ' + DB.GetDBValue(dtISS.Rows[0]["BondSales_ChequeNo"]);
                txtPDPaymentAmount.Text = DB.GetDBIntValue(dtISS.Rows[0]["IssueAmount"]).ToString("0.00");

                try
                {
                    txtOldRegNo.Text = DB.GetDBValue(dtISS.Rows[0]["BondSales_OldRegNo"]);
                    txtCreateBy.Text = DB.GetDBValue(dtISS.Rows[0]["BondSales_CreatedBy"]);
                    txtModifiedBy.Text = DB.GetDBValue(dtISS.Rows[0]["BondSales_ModifiedBy"]);
                    txtConfirmed.Text = DB.GetDBValue(dtISS.Rows[0]["BondSales_Confirmed"]);
                    txtCreateDate.Text = Date.GetDateTimeByString(dtISS.Rows[0]["BondSales_CreatedAt"].ToString()).ToString(Constants.DATETIME_FORMAT);
                    txtModifiedDate.Text = Date.GetDateTimeByString(dtISS.Rows[0]["BondSales_ModifiedAt"].ToString()).ToString(Constants.DATETIME_FORMAT);

                }
                catch (Exception)
                {


                }
                oResult = oOldDataDAL.LoadNomineeDetailsByRegNo(sRegNo);
                if (oResult.Status)
                {
                    DataTable dtNom = (DataTable)oResult.Return;
                    gvNomDetail.DataSource = dtNom;
                    gvNomDetail.DataBind();
                }

                oResult = oOldDataDAL.LoadScriptsDetailsByRegNo(sRegNo);
                if (oResult.Status)
                {
                    DataTable dtScripts = (DataTable)oResult.Return;
                    gvDenomDetail.DataSource = dtScripts;
                    gvDenomDetail.DataBind();
                }

                oResult = oOldDataDAL.LoadInterestDetailsByRegNo(sRegNo);
                if (oResult.Status)
                {
                    DataTable dtInterest = (DataTable)oResult.Return;
                    gvInterest.DataSource = dtInterest;
                    gvInterest.DataBind();
                }
                oResult = oOldDataDAL.LoadEncashmentDetailsByRegNo(sRegNo);
                if (oResult.Status)
                {
                    DataTable dtEncashment = (DataTable)oResult.Return;
                    gvEncashment.DataSource = dtEncashment;
                    gvEncashment.DataBind();
                }
            }
            else
            {
                hdRegNo.Value = "";
                ucMessage.OpenMessage(Constants.MSG_ERROR_NOT_FOUND, Constants.MSG_TYPE_ERROR);
            }
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        protected void btnShowPolicy_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(hdRegNo.Value))
            {
                if (ddlSpType.SelectedIndex != 0)
                {
                    SPPolicy oPolicy = null;
                    SPPolicyDAL oSPPolicyDAL = new SPPolicyDAL();
                    Result oResult = null;
                    if (string.IsNullOrEmpty(txtIssueDate.Text))
                    {
                        oResult = (Result)oSPPolicyDAL.GetLatestPolicyDetail(ddlSpType.SelectedValue, Constants.ACTIVITY_TYPE.ISSUE, DateTime.Now);
                    }
                    else
                    {
                        oResult = (Result)oSPPolicyDAL.GetLatestPolicyDetail(ddlSpType.SelectedValue, Constants.ACTIVITY_TYPE.ISSUE, Date.GetDateTimeByString(txtIssueDate.Text.ToString()));
                    }

                    if (oResult.Status)
                    {
                        oPolicy = (SPPolicy)oResult.Return;
                        PD.SetPolicyDetails(oPolicy);
                    }
                }
            }
            else
            {
                ucMessage.OpenMessage("You must load Issue first before viewing policy Detail!", Constants.MSG_TYPE_INFO);
            }
        }

        protected void btnExportIntDetails_Click(object sender, EventArgs e)
        {
            OldDataDAL oOldDataDAL = new OldDataDAL();
            Result oResult = new Result();
            Config oConfig = (Config)Session[Constants.SES_USER_CONFIG];

            if (oConfig != null)
            {
                // Parameter
                oResult = oOldDataDAL.LoadInterestDetailsByRegNo(txtRegistrationNo.Text);
                if (oResult.Status)
                {
                    this.ExportToCSV((DataTable)oResult.Return, "Old_Int_Dump");
                }
                else
                {
                    ucMessage.OpenMessage("Interest records not available with the registration details!", Constants.MSG_TYPE_INFO);
                }
            }
        }
        protected void btnExportEncashmentDetails_Click(object sender, EventArgs e)
        {
            OldDataDAL oOldDataDAL = new OldDataDAL();
            Result oResult = new Result();
            Config oConfig = (Config)Session[Constants.SES_USER_CONFIG];

            if (oConfig != null)
            {
                // Parameter
                oResult = oOldDataDAL.LoadEncashmentDetailsByRegNo(txtRegistrationNo.Text);
                if (oResult.Status)
                {
                    this.ExportToCSV((DataTable)oResult.Return, "Old_Enc_Dump");
                }
                else
                {
                    ucMessage.OpenMessage("Encashment records not available with the registration details!", Constants.MSG_TYPE_INFO);
                }
            }
        }

        private void ExportToCSV(DataTable table, string name)
        {
            table.TableName = name;
            string sValue = "";
            HttpContext context = HttpContext.Current;
            context.Response.Clear();
            foreach (DataColumn column in table.Columns)
            {
                context.Response.Write(column.ColumnName + ",");
            }
            context.Response.Write(Environment.NewLine);
            foreach (DataRow row in table.Rows)
            {
                for (int i = 0; i < table.Columns.Count; i++)
                {
                    if (row[i].GetType() == System.Type.GetType("System.DateTime"))
                    {
                        if (row[i] != DBNull.Value)
                        {
                            sValue = ((DateTime)row[i]).ToShortDateString();
                        }
                        else
                        {
                            sValue = "";
                        }
                        sValue = sValue.Replace(",", string.Empty);
                    }
                    else
                    {
                        sValue = row[i].ToString().Replace(",", string.Empty);
                        //sValue = sValue.Replace(";", string.Empty);
                    }

                    sValue = sValue.Replace("\n", string.Empty);
                    sValue = sValue.Replace("\r", string.Empty);
                    sValue = sValue.Replace("\t", string.Empty);
                    sValue = sValue.Replace(",", string.Empty);
                    context.Response.Write(sValue + ",");
                    sValue = "";
                }
                context.Response.Write(Environment.NewLine);
            }
            context.Response.ContentType = "text/csv";
            context.Response.AppendHeader("Content-Disposition", "attachment; filename=" + table.TableName.Trim() + ".csv");
            context.Response.End();
        }

    }
}
